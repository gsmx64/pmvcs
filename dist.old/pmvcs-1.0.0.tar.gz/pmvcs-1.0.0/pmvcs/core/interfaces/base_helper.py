""" Abstract Base Helper file for Python MVC Shell Framework Package """
from abc import ABC, abstractmethod


class AbstractBaseHelper(ABC):
    """ Class for PMVCS Abstract Base Helper """
