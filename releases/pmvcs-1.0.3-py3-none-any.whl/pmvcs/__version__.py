""" __version__ file for Python MVC Shell Framework Package """
VERSION = (1, 0, 3)
__version__ = '.'.join(map(str, VERSION))
