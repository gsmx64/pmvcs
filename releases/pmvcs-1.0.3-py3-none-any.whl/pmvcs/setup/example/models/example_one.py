""" Example One Model file for PMVCS APP """
from app.models.base_model import BaseModel


class ExampleOneModel(BaseModel):
    """ Class for Example One Model """
