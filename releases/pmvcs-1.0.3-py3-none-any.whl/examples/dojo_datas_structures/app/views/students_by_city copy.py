""" Students By City View file for Dojo_Datastructures
Reto: Obtener todos los estudiantes que pertenezcan a una ciudad dada."""
from app.views.base_view import BaseView


class StudentsByCityView(BaseView):
    """ Class for Students By City View  """
