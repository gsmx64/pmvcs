""" Students` Cities Residence View file for Dojo_Datastructures
Reto: Obtener todas las ciudades de residencia de los estudiantes."""
from app.views.base_view import BaseView


class StudentsCitiesResidenceView(BaseView):
    """ Class for Students` Cities Residence View """
