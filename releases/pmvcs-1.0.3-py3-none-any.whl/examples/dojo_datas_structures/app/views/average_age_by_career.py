""" Average Age By Career View file for Dojo_Datastructures
Reto: Identificar la edad promedio por carrera."""
from app.views.base_view import BaseView


class AverageAgeByCareerView(BaseView):
    """ Class for Average Age By Career View """
