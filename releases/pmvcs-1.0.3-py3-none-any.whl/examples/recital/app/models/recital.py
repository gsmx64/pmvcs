""" Recital Model file for PMVCS APP """
from app.models.base_model import BaseModel


class RecitalModel(BaseModel):
    """ Class for Recital Model """
