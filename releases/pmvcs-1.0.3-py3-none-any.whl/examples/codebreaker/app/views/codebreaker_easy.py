""" Codebreaker Easy View file for PMVCS APP """
from app.views.base_view import BaseView


class CodebreakerEasyView(BaseView):
    """ Class for Codebreaker Easy View  """
