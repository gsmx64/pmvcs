""" Codebreaker Normal Model file for PMVCS APP """
from app.models.base_model import BaseModel


class CodebreakerNormalModel(BaseModel):
    """ Class for Codebreaker Normal Model """
