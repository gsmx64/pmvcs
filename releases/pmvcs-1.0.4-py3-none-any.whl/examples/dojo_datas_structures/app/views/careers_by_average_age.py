""" Careers By Average Age View file for Dojo_Datastructures
Reto: Indicar por carrera si el estudiante está por encima o por debajo del promedio de edad."""
from app.views.base_view import BaseView


class CareersByAverageAgeView(BaseView):
    """ Class for Careers By Average Age  """
