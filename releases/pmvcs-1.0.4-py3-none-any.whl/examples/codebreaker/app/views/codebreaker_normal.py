""" Codebreaker Normal View file for PMVCS APP """
from app.views.base_view import BaseView


class CodebreakerNormalView(BaseView):
    """ Class for Codebreaker Normal View  """
