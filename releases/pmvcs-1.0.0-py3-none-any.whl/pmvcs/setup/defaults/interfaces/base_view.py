""" Base View file for PMVCS APP """
from abc import ABC, abstractmethod


class AbstractBaseView(ABC):
    """ Class for Base View """
