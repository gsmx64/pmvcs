""" Base Model file for PMVCS APP """
from abc import ABC, abstractmethod


class AbstractBaseModel(ABC):
    """ Class for Base Model """
    _data = ''
