""" Students By Average Age View file for Dojo_Datastructures
Reto: Agrupa los estudiantes en diferentes rangos de edad (18-25, 26-35, mayores de 35)."""
from app.views.base_view import BaseView


class StudentsByAverageAgeView(BaseView):
    """ Class for Students By Average Age View  """
