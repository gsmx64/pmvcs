""" Students By Age View file for Dojo_Datastructures
Reto: Obtener todos los estudiantes que estén dentro del rango de edades dado."""
from app.views.base_view import BaseView


class StudentsByAgeView(BaseView):
    """ Class for Students By Age View  """
