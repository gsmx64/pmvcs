""" City With More Careers View file for Dojo_Datastructures
Reto: Identifica la ciudad que tienen la mayor variedad de carreras universitarias entre los estudiantes."""
from app.views.base_view import BaseView


class CityWithMoreCareersView(BaseView):
    """ Class for City With More Careers View  """
