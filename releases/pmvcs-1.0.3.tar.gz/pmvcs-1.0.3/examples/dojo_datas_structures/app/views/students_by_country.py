""" Students By Country View file for Dojo_Datastructures
Reto: Obtener todos los estudiantes que vivan en un país dado."""
from app.views.base_view import BaseView


class StudentsByCountryView(BaseView):
    """ Class for Students By Country View  """
