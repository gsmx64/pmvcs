""" __main__ file for Python MVC Shell Framework Package """
from pmvcs.pmvcs import main

if __name__ == '__main__':
    main()
