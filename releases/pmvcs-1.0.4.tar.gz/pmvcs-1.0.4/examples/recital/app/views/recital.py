""" Recital View file for PMVCS APP """
from app.views.base_view import BaseView


class RecitalView(BaseView):
    """ Class for Recital View  """
