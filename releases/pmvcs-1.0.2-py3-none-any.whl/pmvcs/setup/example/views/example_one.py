""" Example One View file for PMVCS APP """
from app.views.base_view import BaseView


class ExampleOneView(BaseView):
    """ Class for Example One View  """
