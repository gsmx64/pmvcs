""" Codebreaker Easy Model file for PMVCS APP """
from app.models.base_model import BaseModel


class CodebreakerEasyModel(BaseModel):
    """ Class for Codebreaker Easy Model """
