""" Codebreaker Hard Model file for PMVCS APP """
from app.models.base_model import BaseModel


class CodebreakerHardModel(BaseModel):
    """ Class for Codebreaker Hard Model """
