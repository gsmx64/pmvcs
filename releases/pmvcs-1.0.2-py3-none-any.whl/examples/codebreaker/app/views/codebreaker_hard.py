""" Codebreaker Hard View file for PMVCS APP """
from app.views.base_view import BaseView


class CodebreakerHardView(BaseView):
    """ Class for Codebreaker Hard View  """
